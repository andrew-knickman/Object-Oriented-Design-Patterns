
public interface MenuInterface 
{
	boolean hasNext();
	MenuItem next();
}
