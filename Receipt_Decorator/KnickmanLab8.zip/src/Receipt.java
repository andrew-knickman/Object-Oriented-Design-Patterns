
public interface Receipt 
{
	public String display();
}
