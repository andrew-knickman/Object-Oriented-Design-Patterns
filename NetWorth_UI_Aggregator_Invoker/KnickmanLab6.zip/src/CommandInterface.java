
public interface CommandInterface 
{
	Object execute();

}
