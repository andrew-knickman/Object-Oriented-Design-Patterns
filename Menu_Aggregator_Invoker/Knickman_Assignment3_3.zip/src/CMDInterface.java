
public interface CMDInterface 
{
	public Object execute();
}
