import java.util.*;

public class SystemInterface 
{
	private Invoker invoker;
	
	public SystemInterface(Invoker invoker)
	{
		this.invoker = invoker;
	}
	public String[] getMenu()
	{
		Menu menu = invoker.getMenu();
		
		//convert Menu object to array of strings
		ArrayList<String> displayLines = new ArrayList<>();
		
		menu.reset();
		while(menu.hasNext())
		{
			displayLines.add(menu.getNextItem().toString());
		}
		
		//return display_lines
		
		return (String[]) displayLines.toArray();
	}
	public String[] submitOrder(int item_number)
	{
		Orders order = invoker.submitOrder();
		Menu menu = invoker.getMenu();
		boolean match = false;
		
		while(menu.hasNext() && match == false)
		{
			MenuItem next = menu.getNextItem();
			if(next.getItemNumber() == item_number)
			{
				order.addOrder(new OrderItem(next));
				match = true;
			}
		}
		
		ArrayList<String> orderLines = new ArrayList<>();
		
		order.reset();
		while(order.hasNext())
		{
			orderLines.add(order.getNextOrder().toString());
		}
		
		return (String[]) orderLines.toArray();
	}
	public String[] getTab()
	{
		Tab tab = invoker.getTab();
		
		return tab.getTab();
	}
}
