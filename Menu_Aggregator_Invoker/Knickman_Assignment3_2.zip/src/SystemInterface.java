import java.util.*;

public class SystemInterface 
{
	private Invoker invoker;
	
	public SystemInterface(Invoker invoker)
	{
		this.invoker = invoker;
	}
	public String[] getMenu()
	{
		Menu menu = invoker.getMenu();
		
		//convert Menu object to array of strings
		ArrayList<String> displayLines = new ArrayList<>();
		
		menu.reset();
		while(menu.hasNext())
		{
			displayLines.add(menu.getNextItem().toString());
		}

		//got can't cast Object to String exception with this return
		//return (String[]) displayLines.toArray();
		
		menu.reset();
		String[] convertedLines = new String[displayLines.size()];
		for(int i = 0; i < convertedLines.length; i++)
		{
			if(menu.hasNext())
				convertedLines[i] = displayLines.get(i);
		}
				
		return convertedLines;
		

		//return display_lines
		
	}
	public String[] submitOrder(int item_number)
	{
		Orders order = invoker.submitOrder();
		Menu menu = invoker.getMenu();
		boolean match = false;
		
		while(menu.hasNext() && match == false)
		{
			MenuItem next = menu.getNextItem();
			if(next.getItemNumber() == item_number)
			{
				order.addOrder(new OrderItem(next));
				match = true;
			}
		}
		
		ArrayList<String> orderLines = new ArrayList<>();
		
		order.reset();
		while(order.hasNext())
		{
			orderLines.add(order.getNextOrder().toString());
		}
		
		return (String[]) orderLines.toArray();
	}
	public String[] getTab()
	{
		Tab tab = invoker.getTab();
		
		return tab.getTab();
	}
}
