
public class CMDGetMenu implements CMDInterface
{
	private Aggregator agg;
	
	public CMDGetMenu(Aggregator agg)
	{
		this.agg = agg;
	}
	
	public Menu execute()
	{
		return new Menu(agg.getMenu());
		//return agg.getMenu().clone(); //clone method
	}

}
