
public class RestaurantSystem 
{
	public static void main(String[] args) 
	{
		Aggregator agg = new Aggregator();
		Invoker invoker = new Invoker(agg);
		SystemInterface si = new SystemInterface(invoker);
		UserInterface ui = new UserInterface(si);
		ui.start();
	}
}
