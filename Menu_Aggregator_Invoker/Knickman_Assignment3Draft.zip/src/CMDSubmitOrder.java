
public class CMDSubmitOrder 
{
	private Aggregator agg;
	
	public CMDSubmitOrder(Aggregator agg)
	{
		this.agg = agg;
	}
	
	public Orders execute()
	{
		return new Orders();
		//return agg.getMenu().clone(); //clone method
	}

}
