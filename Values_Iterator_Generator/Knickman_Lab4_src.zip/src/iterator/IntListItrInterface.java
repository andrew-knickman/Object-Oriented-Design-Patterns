package iterator;

public interface IntListItrInterface 
{
	boolean hasNext();
	int next();
}
