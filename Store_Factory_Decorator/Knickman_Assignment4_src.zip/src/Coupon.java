
public interface Coupon extends AddOn 
{
	
}
