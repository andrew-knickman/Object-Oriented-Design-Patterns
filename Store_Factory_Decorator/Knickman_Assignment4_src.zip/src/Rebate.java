
public interface Rebate extends AddOn
{

}
