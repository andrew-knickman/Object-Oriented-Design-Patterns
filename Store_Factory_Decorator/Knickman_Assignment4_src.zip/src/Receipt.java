
public interface Receipt 
{
	public void printReceipt();
}
